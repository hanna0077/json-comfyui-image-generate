<script lang="ts">
	import { onMount, onDestroy } from 'svelte';
	import { goto } from '$app/navigation';
	import { page } from '$app/stores';
	import { get } from 'svelte/store';

	let generatedImages: string[] = [];
	let isGenerating = true;
	let errorMessage = '';
	let currentIndex = 0;
	let pollInterval: number | undefined;

	onMount(async () => {
		// localStorage에서 생성 요청 정보 가져오기
		const requestData = localStorage.getItem('generationRequest');

		if (!requestData) {
			errorMessage = '생성 요청 정보가 없습니다.';
			isGenerating = false;
			return;
		}

		const { workflow, prompt, subfolder } = JSON.parse(requestData);

		// 이미지 생성 시작
		try {
			let response;

			try {
				const jsonData = JSON.parse(prompt);

				// 'event' 또는 'events' 배열이 있는지 확인
				if ((jsonData && jsonData.event && Array.isArray(jsonData.event)) ||
				    (jsonData && jsonData.events && Array.isArray(jsonData.events))) {
					response = await fetch('http://127.0.0.1:5000/generate', {
						method: 'POST',
						headers: { 'Content-Type': 'application/json' },
						body: JSON.stringify({ prompt: jsonData, workflow, subfolder })
					});
				} else {
					throw new Error('올바른 JSON 형식이 아닙니다.');
				}
			} catch {
				// 일반 텍스트로 처리
				response = await fetch('http://127.0.0.1:5000/generate', {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ workflow, prompt, subfolder })
				});
			}

			const data = await response.json();
			console.log('서버 응답:', data); // 디버깅용 로그

			if (!response.ok) {
				throw new Error(data.error || `서버 오류: ${response.status}`);
			}

			// 단수형(image_url)과 복수형(image_urls) 모두 지원
			let imageUrls: string[] = [];

			if (data.image_url) {
				// 단수형인 경우 배열로 변환
				imageUrls = [data.image_url];
			} else if (data.image_urls && data.image_urls.length > 0) {
				// 복수형인 경우
				imageUrls = data.image_urls;
			}

			if (imageUrls.length > 0) {
				const validUrls = imageUrls.filter((url: string) => url !== 'timeout');
				console.log('유효한 이미지 URLs:', validUrls); // 디버깅용 로그

				if (validUrls.length > 0) {
					generatedImages = validUrls;
					currentIndex = 0;
				} else {
					throw new Error('이미지 생성에 실패했습니다 (타임아웃). 다시 시도해주세요.');
				}
			} else if (data.error) {
				throw new Error(`서버 에러: ${data.error}`);
			} else {
				console.error('예상치 못한 응답 구조:', data);
				throw new Error('이미지 생성에 실패했습니다. 응답 형식이 올바르지 않습니다.');
			}
		} catch (error) {
			errorMessage = error instanceof Error ? error.message : '서버와의 연결에 실패했습니다.';
			console.error('에러 상세:', error);
		} finally {
			isGenerating = false;
		}
	});

	onDestroy(() => {
		if (pollInterval) {
			clearInterval(pollInterval);
		}
	});

	function selectImage(index: number) {
		currentIndex = index;
	}

	function goBack() {
		goto('/prompt');
	}

	function goHome() {
		goto('/');
	}

	function downloadImage(url: string, index: number) {
		const link = document.createElement('a');
		link.href = url;
		link.download = `generated-image-${index + 1}.png`;
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	}

	// 이미지 로드 에러 핸들링
	function handleImageError(event: Event, index: number) {
		console.error(`이미지 로드 실패 (${index + 1}):`, generatedImages[index]);
		errorMessage = `이미지 ${index + 1} 로드에 실패했습니다. URL: ${generatedImages[index]}`;
	}
</script>

<section class="min-h-screen flex items-center justify-center p-4 sm:p-6 py-8 bg-neutral-900">
	<div class="w-full max-w-sm sm:max-w-md md:max-w-2xl lg:max-w-4xl xl:max-w-6xl rounded-xl sm:rounded-2xl bg-teal-500 p-4 sm:p-6 shadow-lg outline outline-black/5">
		<!-- 상단 장식 및 헤더 -->
		<div class="mb-3 flex justify-between items-center">
			<button
				on:click={goBack}
				class="rounded-md sm:rounded-lg bg-teal-700 px-3 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm md:text-base font-medium text-white hover:bg-teal-800 transition-colors shadow-md"
			>
				← 돌아가기
			</button>
			<div class="flex gap-1 sm:gap-2">
				<i class="material-symbols-rounded text-2xl sm:text-3xl md:text-4xl opacity-20" style="color:black;">
					image
				</i>
				<i class="material-symbols-rounded text-2xl sm:text-3xl md:text-4xl opacity-20" style="color:black;">
					photo_library
				</i>
			</div>
			<div class="w-16 sm:w-20 md:w-24"></div>
		</div>

		<!-- 메인 타이틀 섹션 -->
		<div class="mb-4 sm:mb-6 rounded-lg sm:rounded-xl bg-teal-600 p-2 sm:p-3 text-neutral-950">
			<div class="rounded-md sm:rounded-lg bg-teal-200 p-3 sm:p-4">
				<h3 class="text-xl sm:text-2xl md:text-3xl font-semibold opacity-80">이미지 미리보기</h3>
				<p class="mt-2 sm:mt-3 text-sm sm:text-base md:text-lg leading-relaxed font-semibold opacity-60">
					생성된 이미지를 확인하고 다운로드하세요
				</p>
			</div>
		</div>

		{#if isGenerating}
			<div class="mb-3 sm:mb-4 rounded-lg sm:rounded-xl bg-yellow-400 p-3 sm:p-4 text-center shadow-md">
				<p class="text-sm sm:text-base font-semibold text-neutral-900">이미지 생성 중...</p>
				<div class="mt-2 sm:mt-3 flex justify-center">
					<div class="h-6 w-6 sm:h-8 sm:w-8 animate-spin rounded-full border-4 border-neutral-900 border-t-transparent"></div>
				</div>
			</div>
		{/if}

		{#if errorMessage}
			<div class="mb-3 sm:mb-4 rounded-lg sm:rounded-xl bg-red-500 p-3 sm:p-4 text-center shadow-md">
				<p class="text-sm sm:text-base font-semibold text-white">{errorMessage}</p>
				<button
					on:click={() => {
						errorMessage = '';
						window.location.reload();
					}}
					class="mt-2 sm:mt-3 rounded-md sm:rounded-lg bg-white px-3 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm font-medium text-red-600 hover:bg-red-50 transition-colors shadow-sm"
				>
					🔄 다시 시도
				</button>
			</div>
		{/if}

		{#if generatedImages.length > 0}
			<!-- Main Image Display -->
			<div class="mb-3 sm:mb-4 rounded-lg sm:rounded-xl bg-teal-600 p-2 sm:p-3">
				<div class="rounded-md sm:rounded-lg bg-white p-3 sm:p-4">
					<div class="relative">
						<img
							src={generatedImages[currentIndex]}
							alt={`생성된 이미지 ${currentIndex + 1}`}
							class="mx-auto max-h-[350px] sm:max-h-[450px] md:max-h-[550px] w-auto rounded-md object-contain"
							on:error={(e) => handleImageError(e, currentIndex)}
						/>
						<button
							on:click={() => downloadImage(generatedImages[currentIndex], currentIndex)}
							class="absolute bottom-2 right-2 sm:bottom-3 sm:right-3 rounded-md sm:rounded-lg bg-purple-600 px-3 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm md:text-base font-medium text-white hover:bg-purple-700 transition-colors shadow-md"
						>
							💾 다운로드
						</button>
					</div>
					<div class="mt-3 sm:mt-4 text-center">
						<p class="text-sm sm:text-base md:text-lg font-semibold text-neutral-900">이미지 {currentIndex + 1} / {generatedImages.length}</p>
						<p class="mt-1 sm:mt-2 text-xs sm:text-sm text-neutral-600 break-all px-2">URL: {generatedImages[currentIndex]}</p>
					</div>
				</div>
			</div>

			<!-- Thumbnail Grid -->
			{#if generatedImages.length > 1}
				<div class="rounded-lg sm:rounded-xl bg-teal-600 p-2 sm:p-3">
					<div class="rounded-md sm:rounded-lg bg-teal-100 p-2.5 sm:p-3">
						<h2 class="mb-2 sm:mb-3 text-base sm:text-lg font-semibold text-neutral-900">모든 이미지</h2>
						<div class="grid grid-cols-2 gap-2 sm:gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
							{#each generatedImages as url, i}
								<button
									on:click={() => selectImage(i)}
									class="group relative overflow-hidden rounded-md border-2 transition-all {i === currentIndex
										? 'border-amber-600 ring-2 ring-amber-500'
										: 'border-teal-300 hover:border-amber-400'}"
								>
									<img
										src={url}
										alt={`썸네일 ${i + 1}`}
										class="h-24 sm:h-28 md:h-32 w-full object-cover transition-transform group-hover:scale-110"
										on:error={(e) => handleImageError(e, i)}
									/>
									<div
										class="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 transition-opacity group-hover:opacity-100"
									>
										<span class="text-xs sm:text-sm font-semibold text-white">보기</span>
									</div>
								</button>
							{/each}
						</div>
					</div>
				</div>
			{/if}
		{:else if !isGenerating}
			<div class="rounded-lg sm:rounded-xl bg-teal-600 p-3 sm:p-4">
				<div class="rounded-md sm:rounded-lg bg-teal-100 p-6 sm:p-8 text-center">
					<p class="text-base sm:text-lg md:text-xl font-semibold text-neutral-900">생성된 이미지가 없습니다.</p>
					<button
						on:click={goHome}
						class="mt-3 sm:mt-4 -translate-y-1 sm:-translate-y-1.5 rounded-md sm:rounded-lg bg-amber-600 px-4 py-2.5 sm:px-6 sm:py-3 text-sm sm:text-base font-medium text-white
						shadow-[0_4px_0_0_theme('colors.amber.800')] sm:shadow-[0_6px_0_0_theme('colors.amber.800')]
						hover:translate-y-0 hover:shadow-none transition-all duration-150"
					>
						🏠 메인으로 이동
					</button>
				</div>
			</div>
		{/if}

		<!-- 하단 장식 -->
		<div class="mt-6 sm:mt-8 flex justify-center">
			<i class="material-symbols-rounded text-2xl sm:text-3xl md:text-4xl opacity-20" style="color:black;">
				photo_camera
			</i>
		</div>
	</div>
</section>
